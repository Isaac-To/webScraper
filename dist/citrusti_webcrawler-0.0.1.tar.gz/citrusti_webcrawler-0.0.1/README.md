# Citrusti Web Crawler

Built on Python and runs asynchronously. It's fairly fast and is designed to be simple.